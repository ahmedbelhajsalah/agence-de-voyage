#include <gtk/gtk.h>


void
on_soumettre_clicked                   (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rechercher_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);
